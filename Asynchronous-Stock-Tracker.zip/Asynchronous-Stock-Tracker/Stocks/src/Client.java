import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
    public static void main(String []args){
        if (args.length != 2) {
            System.exit(1);
        }
        System.out.println("HELLO Welcome to Essayas stoke tracker program");
        System.out.println("No need to worry about power outage your information is begin saved automatically");
        System.out.println("PLEASE LOG IN FIRST");
        System.out.println("PLEASE ENTER IN THIS FORMAT(\"user name\") OR (\"USER NAME\") example user essayas");

        String hostName = args[0];
        int portNumber = Integer.parseInt(args[1]);

        try (
                Socket echoSocket = new Socket(hostName, portNumber);
                PrintWriter out =
                        new PrintWriter(echoSocket.getOutputStream(), true);
                BufferedReader in =
                        new BufferedReader(
                                new InputStreamReader(echoSocket.getInputStream()));
                BufferedReader stdIn =
                        new BufferedReader(
                                new InputStreamReader(System.in))
        ) {
            String userInput;
            while ((userInput = stdIn.readLine()) != null) {
                System.out.println("Client: " + userInput);
                out.println(userInput);
                out.flush();
                System.out.println("Server: " + in.readLine());
                System.out.println("Available commands (PORTFOLIO(to view all stocks), FORGET stockName(to remove a stock), TRACK stockName(to add a stock), USER name(to login to another profile))");

            }
        } catch (UnknownHostException e) {
            System.err.println("Don't know about host " + hostName);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for the connection to " +
                    hostName);
            System.exit(1);
        }
    }
}
