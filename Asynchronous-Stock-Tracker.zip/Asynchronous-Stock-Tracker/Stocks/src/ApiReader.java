import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.Charset;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ApiReader {
    private Lock lock;
    String urlString = "https://financialmodelingprep.com/api/v3/stock/real-time-price/";
    public ApiReader(){
        lock=new ReentrantLock();
    }
    public  double getStock(String name) throws URISyntaxException, IOException, InterruptedException {
        lock.lock();
        var uri = new URI(urlString + name);
        var client = HttpClient.newBuilder().build();
        var request = HttpRequest.newBuilder(uri).build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString(Charset.defaultCharset()));
        lock.unlock();
        return StockPriceParser.parsePrice(response.body());
    }
}

