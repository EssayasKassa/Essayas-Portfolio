import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String []args) throws ClassNotFoundException, IOException {
        int port;
        if(args.length!=1) {
            return;
        }

        port=Integer.parseInt(args[0]);
        StockDataBase s=new StockDataBase();
        ApiReader r= new ApiReader();
        try(ServerSocket serverSocket=new ServerSocket(port);) {
            while (true){
                Socket client=serverSocket.accept();
                System.out.println("CONNECTION");
                Service service=new Service(client, r);
                Thread t=new Thread(service);
                t.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}


