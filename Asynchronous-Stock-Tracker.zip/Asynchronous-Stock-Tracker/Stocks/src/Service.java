import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Scanner;

public class Service implements Runnable{
    Socket socket;
    ApiReader reader;
    private Scanner in;
    private PrintWriter out;
    private String userName;
    private ArrayList<String> stockList;
    Service(Socket s, ApiReader r){
        socket=s;
        reader=r;
        stockList=new ArrayList<>();
    }
    public void run(){

        try {
            try {
                in = new Scanner(socket.getInputStream());
                out = new PrintWriter(socket.getOutputStream());
                doService();
            }finally {
                socket.close();
            }
        } catch (IOException | InterruptedException | URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public void doService() throws InterruptedException, IOException, URISyntaxException {
        String next;
        while((next=in.nextLine())!=null){
            int index=-1;
            if ((next.indexOf("USER"))==0 || (next.indexOf("user"))==0){
                index=0;
                userName=next.substring(4,next.length()).trim();
                boolean statues=StockDataBase.createUser(userName);
                if(!statues){
                    System.out.println("new user");
                }
                out.println("OK");
                out.flush();
            }
            else if ((next.indexOf("TRACK"))==0 ||(next.indexOf("track"))==0 ){
                index=0;
                String stock=next.substring(5,next.length()).trim();
                System.out.println("TRACK");
                StockDataBase.updateUserStock(userName,1,stock);
                out.println("OK");
                out.flush();
            }
            else if ((next.indexOf("FORGET"))==0||(next.indexOf("forget"))==0){
                index=0;
                System.out.println("FORGET");
                String stock=next.substring(6,next.length()).trim();
                StockDataBase.updateUserStock(userName,2,stock);
                out.println("OK");
                out.flush();
            }
            else if ((next.indexOf("PORTFOLIO"))==0||(next.indexOf("portfolio"))==0){
                index=0;
                String stocks="";
                stockList=StockDataBase.getStocks(userName);
                for(String i: stockList){
                    double price=reader.getStock(i);
                    stocks+=i+" "+price +"  " ;
                }
                out.println(stocks);
                out.flush();
            }
            else
            {
                out.println("error");
                out.flush();
            }

        }
    }

}
