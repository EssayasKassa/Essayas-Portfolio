import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class StockDataBase {
    public StockDataBase() throws IOException, ClassNotFoundException {
        SimpleDataSource.init("database.properties");
        try (Connection conn = SimpleDataSource.getConnection())  {
            ResultSet rs = conn.getMetaData().getTables(null,null,"LIST", new String[] {"TABLE"});
            if(!rs.next()) {
                System.out.println("make table");
                Statement stat = conn.createStatement();
                stat.execute("CREATE TABLE LIST (UserName VARCHAR(20))");
            }

        } catch(SQLException e ) {
            e.printStackTrace();
        }

    }
    public static boolean checkUserName(String name){
        try(Connection connection= SimpleDataSource.getConnection()) {
            PreparedStatement statement=connection.prepareStatement("SELECT * FROM LIST WHERE UserName = ?");
            statement.setString(1,name);
            ResultSet result= statement.executeQuery();
            return result.next();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    public static boolean createUser(String name){
        System.out.println("check user name "+name +" "+checkUserName("daniel"));
        if(!(checkUserName(name))){
            try(Connection connection= SimpleDataSource.getConnection()) {
                Statement statement=connection.createStatement();
                statement.execute("CREATE TABLE "+name+" (StockNames VARCHAR(20))");
                statement.execute("INSERT INTO LIST (UserName) VALUES ('"+name+"')");
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    public static void print(){


    }
    public static boolean updateUserStock(String user,int i,String Stock){
        if(i==1) {
            try (Connection connection = SimpleDataSource.getConnection()) {
                Statement statement=connection.createStatement();
                statement.execute("INSERT INTO "+user+" (StockNames) VALUES ('"+Stock+"')");
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else if(i==2){
            try (Connection connection = SimpleDataSource.getConnection()) {
                Statement statement=connection.createStatement();
                String query = "DELETE FROM  "+user+" WHERE StockNames = '"+Stock+"'";
                statement.executeUpdate(query);
                String query2 = "DELETE FROM  LIST WHERE UserName = '"+Stock+"'";
                statement.executeUpdate(query2);
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

        return false;
    }
    public static boolean deleteUser(String user){
        try(Connection connection= SimpleDataSource.getConnection()) {
            Statement statement=connection.createStatement();
            String query = "DELETE FROM  LIST WHERE UserName = '"+user+"'";
            statement.executeUpdate(query);
            String query2 = "DROP TABLE "+user;
            statement.execute(query2);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static ArrayList<String>getStocks(String user){
        ArrayList<String>result=new ArrayList<>();
        try(Connection connection= SimpleDataSource.getConnection()) {
            Statement statement=connection.createStatement();
            ResultSet r=statement.executeQuery("SELECT * FROM "+user);
            while(r.next()){
                result.add(r.getString("StockNames"));
            }
            for(String s:result){
                System.out.println(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }



}
